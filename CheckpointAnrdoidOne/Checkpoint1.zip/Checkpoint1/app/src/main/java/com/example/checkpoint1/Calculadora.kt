package com.example.checkpoint1

import android.os.Bundle
import android.widget.RadioButton
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_calculadora.*

class Calculadora : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calculadora)

        val rbSomar = findViewById<RadioButton>(R.id.radioButtonSoma)
        val rbSub = findViewById<RadioButton>(R.id.radioButtonSub)
        val rbMult = findViewById<RadioButton>(R.id.radioButtonMult)
        /*val rbDiv = findViewById<RadioButton>(R.id.radioButtonDiv)*/

        buttonCalcular.setOnClickListener{
            val somar = editTextV1.text.toString().toDouble()
            val somar2 = editTextV2.text.toString().toDouble()
            val conta : Double

            if (rbSomar.isChecked) {
                conta = (somar) + (somar2)
            }
            else if (rbSub.isChecked) {
                conta = (somar) - (somar2)
            }
            else if (rbMult.isChecked) {
                conta = (somar) * (somar)
            }
            else {
                conta = (somar) / (somar)
            }
            val resultado = "conta = ${(conta)}"
            Toast.makeText(this, resultado, Toast.LENGTH_LONG).show()
        }

    }
}